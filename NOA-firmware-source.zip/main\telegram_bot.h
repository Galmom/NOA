#ifndef TELEGRAM_BOT_H
#define TELEGRAM_BOT_H

#include <cstdint>
#include <string>
#include <vector>

/**
 * Telegram bot running inside the firmware.
 *
 * It polls Telegram's getUpdates long-poll API from its own task, accepts
 * commands only from the configured chat, keeps its reminders in NVS and
 * notifies both Telegram and the device screen when one is due.
 *
 * Everything it needs to know is in telegram_config.h, which is not tracked.
 */
class TelegramBot {
public:
    static TelegramBot& GetInstance();

    /** Start the polling task. Safe to call once, before the main event loop. */
    void Start();

    TelegramBot(const TelegramBot&) = delete;
    TelegramBot& operator=(const TelegramBot&) = delete;

private:
    struct Reminder {
        int64_t due;
        std::string text;
    };

    TelegramBot();

    static void TaskEntry(void* arg);
    void Run();

    bool CallApi(const std::string& method, const std::string& query,
                 const std::string& body, int timeout_ms, std::string& response);
    bool SendMessage(const std::string& text);
    // Runs a device MCP tool through the same dispatch the AI uses. The handler
    // executes on the main application thread; this task only waits for it.
    bool InvokeTool(const std::string& name, const std::string& arguments_json, std::string& text,
                    int wait_ms = 10000);
    // Sends a raw JSON-RPC message and waits for its reply payload.
    bool SendJsonRpc(const std::string& message, std::string& payload, int wait_ms = 10000);
    // Lists every tool the firmware exposes to the model.
    bool ListTools(std::vector<std::string>& names);
    void PollOnce();
    void HandleCommand(const std::string& text, const std::string& from_chat_id);

    void CheckReminders();
    std::vector<Reminder> LoadReminders();
    void SaveReminders(const std::vector<Reminder>& reminders);
    void Notify(const std::string& text);

    std::string token_;
    std::string chat_id_;
    int64_t offset_ = 0;
    bool started_ = false;
};

#endif  // TELEGRAM_BOT_H
