#include "telegram_bot.h"

#include <cJSON.h>
#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_log.h>
#include <esp_netif_sntp.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <algorithm>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>

#include "application.h"
#include "board.h"
#include "display.h"
#include "mcp_server.h"
#include "settings.h"

#if __has_include("telegram_config.h")
#include "telegram_config.h"
#endif

#ifndef TELEGRAM_BOT_TOKEN
#define TELEGRAM_BOT_TOKEN ""
#endif
#ifndef TELEGRAM_CHAT_ID
#define TELEGRAM_CHAT_ID ""
#endif

#define TAG "TelegramBot"

namespace {
constexpr const char* kApiBase = "https://api.telegram.org";
constexpr const char* kReminderNamespace = "remind";
constexpr const char* kReminderKey = "list";
constexpr int kPollTimeoutSeconds = 10;
constexpr int kPollHttpTimeoutMs = 20000;
constexpr int kApiHttpTimeoutMs = 10000;
// web.search blocks on an HTTP request that can take up to 20 s (Tavily).
constexpr int kSearchWaitMs = 25000;
constexpr size_t kMaxResponseBytes = 32768;
// NVS strings are small and a full store would fail with ESP_ERROR_CHECK.
constexpr size_t kMaxReminders = 10;
constexpr size_t kMaxReminderText = 120;
// 2024-01-01 UTC: anything before this means the clock was never set, and TLS
// certificate validation would fail anyway.
constexpr int64_t kMinValidTime = 1704067200;

std::string Trim(const std::string& value) {
    size_t begin = 0;
    size_t end = value.size();
    while (begin < end && std::isspace(static_cast<unsigned char>(value[begin]))) {
        ++begin;
    }
    while (end > begin && std::isspace(static_cast<unsigned char>(value[end - 1]))) {
        --end;
    }
    return value.substr(begin, end - begin);
}

// The reminder store is one NVS string with "due|text" lines, so the text must
// not contain the separators.
std::string Sanitize(const std::string& value) {
    std::string out;
    out.reserve(value.size());
    for (char c : value) {
        if (c == '\n' || c == '\r' || c == '\t' || c == '|') {
            out += ' ';
        } else {
            out += c;
        }
    }
    return out;
}

std::string JsonEscape(const std::string& value) {
    std::string out;
    out.reserve(value.size() + 8);
    for (unsigned char c : value) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", c);
                    out += buf;
                } else {
                    out += static_cast<char>(c);
                }
                break;
        }
    }
    return out;
}

std::string FormatTime(int64_t epoch) {
    time_t t = static_cast<time_t>(epoch);
    struct tm tm_value = {};
    localtime_r(&t, &tm_value);
    char buf[32];
    strftime(buf, sizeof(buf), "%d/%m %H:%M", &tm_value);
    return buf;
}

std::string FormatClock() {
    time_t t = time(nullptr);
    struct tm tm_value = {};
    localtime_r(&t, &tm_value);
    char buf[16];
    strftime(buf, sizeof(buf), "%H:%M", &tm_value);
    return buf;
}

const char* StateName(DeviceState state) {
    switch (state) {
        case kDeviceStateStarting: return "Iniciando";
        case kDeviceStateWifiConfiguring: return "Configurando WiFi";
        case kDeviceStateIdle: return "Inactivo";
        case kDeviceStateConnecting: return "Conectando";
        case kDeviceStateListening: return "Escuchando";
        case kDeviceStateSpeaking: return "Hablando";
        case kDeviceStateNotifying: return "Notificando";
        case kDeviceStateUpgrading: return "Actualizando";
        case kDeviceStateActivating: return "Activando";
        case kDeviceStateAudioTesting: return "Probando audio";
        case kDeviceStateFatalError: return "Error";
        default: return "Desconocido";
    }
}

// Accepts "10m", "2h", "30s", "1d" and "18:30".
bool ParseWhen(const std::string& spec, int64_t now, int64_t& due) {
    if (spec.find(':') != std::string::npos) {
        int hour = -1;
        int minute = -1;
        if (sscanf(spec.c_str(), "%d:%d", &hour, &minute) != 2) {
            return false;
        }
        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            return false;
        }
        time_t now_t = static_cast<time_t>(now);
        struct tm today = {};
        localtime_r(&now_t, &today);
        struct tm target = today;
        target.tm_hour = hour;
        target.tm_min = minute;
        target.tm_sec = 0;
        target.tm_isdst = -1;
        time_t when = mktime(&target);
        if (when <= now_t) {
            when += 24 * 60 * 60;
        }
        due = when;
        return true;
    }

    if (spec.size() < 2) {
        return false;
    }
    int64_t multiplier = 0;
    switch (std::tolower(static_cast<unsigned char>(spec.back()))) {
        case 's': multiplier = 1; break;
        case 'm': multiplier = 60; break;
        case 'h': multiplier = 3600; break;
        case 'd': multiplier = 86400; break;
        default: return false;
    }
    for (size_t i = 0; i + 1 < spec.size(); ++i) {
        if (!std::isdigit(static_cast<unsigned char>(spec[i]))) {
            return false;
        }
    }
    long amount = std::atol(spec.substr(0, spec.size() - 1).c_str());
    if (amount <= 0) {
        return false;
    }
    due = now + static_cast<int64_t>(amount) * multiplier;
    return true;
}

// One entry per public command. `usage` is the canonical form, `aliases` the
// short forms Telegram accepts, and `description` what the command does.
struct CommandEntry {
    const char* usage;
    const char* aliases;
    const char* description;
};

const CommandEntry kCommands[] = {
    {"/recordar 10m Sacar la ropa", "/r", "Crea un recordatorio (10m, 2h o 18:30)"},
    {"/recordatorios", "/rec", "Lista los pendientes y cuántos son"},
    {"/cancelar 3", "/c", "Borra el recordatorio número 3"},
    {"/aviso Hola", "/a", "Muestra el mensaje en la pantalla"},
    {"/estado", "/e", "Hora, estado del equipo y recordatorios pendientes"},
    {"/dispositivo", "/d", "Estado completo del dispositivo (audio, pantalla, red, batería)"},
    {"/volumen 60", "/v", "Volumen del parlante del dispositivo, 0-100"},
    {"/brillo 40", "/b", "Brillo de la pantalla del dispositivo, 1-100"},
    {"/tema light|dark", "/t", "Cambia el tema de la pantalla"},
    {"/bw clima de argentina", "", "Busca en la web (Tavily)"},
    {"/tool", "/x", "Uso avanzado: lista o ejecuta una herramienta por nombre"},
    {"/ayuda", "/h", "Esta lista"},
};

std::string BuildHelpText() {
    std::string text = "Comandos (cada uno tiene su forma corta):";
    for (const auto& entry : kCommands) {
        text += "\n";
        text += entry.usage;
        if (entry.aliases[0] != '\0') {
            text += "  [";
            text += entry.aliases;
            text += "]";
        }
        text += "  ";
        text += entry.description;
    }
    return text;
}

// Maps an incoming command to its canonical form. Unknown commands stay as is.
std::string CanonicalCommand(const std::string& command) {
    struct Alias {
        const char* name;
        const char* canonical;
    };
    static const Alias kAliases[] = {
        {"/h", "/ayuda"},       {"/help", "/ayuda"},       {"/start", "/ayuda"},
        {"/r", "/recordar"},    {"/remind", "/recordar"},  {"/rec", "/recordatorios"},
        {"/list", "/recordatorios"},                       {"/c", "/cancelar"},
        {"/cancel", "/cancelar"},                          {"/a", "/aviso"},
        {"/notify", "/aviso"},  {"/e", "/estado"},         {"/status", "/estado"},
        {"/d", "/dispositivo"}, {"/device", "/dispositivo"},
        {"/v", "/volumen"},     {"/vol", "/volumen"},      {"/b", "/brillo"},
        {"/bright", "/brillo"}, {"/t", "/tema"},           {"/theme", "/tema"},
        {"/x", "/tool"},
    };
    for (const auto& alias : kAliases) {
        if (command == alias.name) {
            return alias.canonical;
        }
    }
    return command;
}

// Shared with the scheduled handler: a stack capture would dangle if the
// handler ran after the bot task stopped waiting.
struct ToolInvocation {
    std::atomic<bool> done{false};
    std::string payload;
};

}  // namespace

TelegramBot::TelegramBot() {
    token_ = TELEGRAM_BOT_TOKEN;
    chat_id_ = TELEGRAM_CHAT_ID;
}

TelegramBot& TelegramBot::GetInstance() {
    static TelegramBot instance;
    return instance;
}

void TelegramBot::Start() {
    if (started_) {
        return;
    }
    started_ = true;
    if (token_.empty()) {
        ESP_LOGW(TAG, "No Telegram bot token configured; bot disabled");
        return;
    }
    BaseType_t created = xTaskCreatePinnedToCore(TaskEntry, "telegram_bot", 12288, this, 3, nullptr, 0);
    if (created != pdPASS) {
        ESP_LOGE(TAG, "Failed to create Telegram bot task");
        started_ = false;
        return;
    }
    ESP_LOGI(TAG, "Telegram bot task started");
}

void TelegramBot::TaskEntry(void* arg) {
    static_cast<TelegramBot*>(arg)->Run();
    vTaskDelete(nullptr);
}

void TelegramBot::Run() {
    bool sntp_started = false;

    // TLS certificate validation needs a real date, and reminders need a real
    // clock. Activation normally sets the time from the OTA response; SNTP is
    // the fallback and also keeps the drift bounded.
    while (time(nullptr) < kMinValidTime) {
        if (!sntp_started) {
            esp_sntp_config_t config = ESP_NETIF_SNTP_DEFAULT_CONFIG("pool.ntp.org");
            esp_err_t err = esp_netif_sntp_init(&config);
            if (err == ESP_OK) {
                sntp_started = true;
                ESP_LOGI(TAG, "Waiting for network time before polling Telegram");
            } else {
                ESP_LOGW(TAG, "SNTP init failed: %s", esp_err_to_name(err));
            }
        }
        vTaskDelay(pdMS_TO_TICKS(5000));
    }

    ESP_LOGI(TAG, "Telegram bot running (chat filter: %s)", chat_id_.empty() ? "none" : "configured");

    while (true) {
        CheckReminders();
        PollOnce();
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}

bool TelegramBot::CallApi(const std::string& method, const std::string& query,
                          const std::string& body, int timeout_ms, std::string& response) {
    response.clear();
    if (token_.empty()) {
        return false;
    }

    std::string url = std::string(kApiBase) + "/bot" + token_ + "/" + method;
    if (!query.empty()) {
        url += "?" + query;
    }

    esp_http_client_config_t config = {};
    config.url = url.c_str();
    config.method = body.empty() ? HTTP_METHOD_GET : HTTP_METHOD_POST;
    config.crt_bundle_attach = esp_crt_bundle_attach;
    config.timeout_ms = timeout_ms;
    config.buffer_size = 2048;
    config.buffer_size_tx = 2048;

    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == nullptr) {
        ESP_LOGW(TAG, "HTTP client init failed for %s", method.c_str());
        return false;
    }

    // The Telegram Bot API only parses a POST body as JSON when this header is
    // present. Without it the body is read as form data, chat_id is not found
    // and the call fails with HTTP 400 while getUpdates (GET) keeps working.
    if (!body.empty()) {
        esp_http_client_set_header(client, "Content-Type", "application/json");
    }

    bool ok = false;
    int status = 0;
    if (esp_http_client_open(client, body.size()) == ESP_OK) {
        if (!body.empty()) {
            int written = esp_http_client_write(client, body.data(), body.size());
            if (written != static_cast<int>(body.size())) {
                ESP_LOGW(TAG, "Short write for %s: %d/%u", method.c_str(), written,
                         static_cast<unsigned>(body.size()));
            }
        }
        esp_http_client_fetch_headers(client);
        status = esp_http_client_get_status_code(client);

        char buffer[1024];
        int read = 0;
        while ((read = esp_http_client_read(client, buffer, sizeof(buffer))) > 0) {
            if (response.size() + read > kMaxResponseBytes) {
                ESP_LOGW(TAG, "Response for %s exceeded %u bytes", method.c_str(),
                         static_cast<unsigned>(kMaxResponseBytes));
                break;
            }
            response.append(buffer, read);
        }
        ok = status == 200;
        if (!ok) {
            ESP_LOGW(TAG, "%s returned HTTP %d", method.c_str(), status);
        }
    } else {
        ESP_LOGW(TAG, "HTTP open failed for %s", method.c_str());
    }

    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    return ok;
}

bool TelegramBot::SendMessage(const std::string& text) {
    if (chat_id_.empty()) {
        return false;
    }
    std::string body = "{\"chat_id\":\"" + chat_id_ + "\",\"text\":\"" + JsonEscape(text) + "\"}";
    std::string response;
    return CallApi("sendMessage", "", body, kApiHttpTimeoutMs, response);
}

bool TelegramBot::SendJsonRpc(const std::string& message, std::string& payload, int wait_ms) {
    payload.clear();
    auto invocation = std::make_shared<ToolInvocation>();
    McpServer::GetInstance().ParseMessage(message, [invocation](const std::string& reply) {
        invocation->payload = reply;
        invocation->done.store(true);
    });

    // Tool handlers run on the main application thread; wait for them with a bound.
    for (int ticks = 0; ticks < wait_ms / 50 && !invocation->done.load(); ++ticks) {
        vTaskDelay(pdMS_TO_TICKS(50));
    }
    if (!invocation->done.load()) {
        return false;
    }
    payload = invocation->payload;
    return true;
}

bool TelegramBot::ListTools(std::vector<std::string>& names) {
    names.clear();
    std::string cursor;
    for (int page = 0; page < 20; ++page) {
        std::string message = "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/list\",\"params\":{";
        if (!cursor.empty()) {
            message += "\"cursor\":\"" + JsonEscape(cursor) + "\"";
        }
        message += "}}";

        std::string payload;
        if (!SendJsonRpc(message, payload)) {
            return false;
        }
        cJSON* root = cJSON_Parse(payload.c_str());
        if (root == nullptr) {
            return false;
        }
        cJSON* result = cJSON_GetObjectItem(root, "result");
        cJSON* tools = cJSON_IsObject(result) ? cJSON_GetObjectItem(result, "tools") : nullptr;
        if (!cJSON_IsArray(tools)) {
            cJSON_Delete(root);
            return false;
        }
        cJSON* item = nullptr;
        cJSON_ArrayForEach(item, tools) {
            cJSON* name = cJSON_GetObjectItem(item, "name");
            if (cJSON_IsString(name)) {
                names.push_back(name->valuestring);
            }
        }
        cJSON* next = cJSON_GetObjectItem(result, "nextCursor");
        std::string next_cursor = cJSON_IsString(next) ? next->valuestring : "";
        cJSON_Delete(root);
        if (next_cursor.empty()) {
            return true;
        }
        cursor = next_cursor;
    }
    return true;
}

bool TelegramBot::InvokeTool(const std::string& name, const std::string& arguments_json,
                             std::string& text, int wait_ms) {
    text.clear();
    if (name.empty()) {
        return false;
    }

    std::string message = "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/call\",\"params\":"
                          "{\"name\":\"" + JsonEscape(name) + "\",\"arguments\":";
    message += arguments_json.empty() ? "{}" : arguments_json;
    message += "}}";

    std::string payload;
    if (!SendJsonRpc(message, payload, wait_ms)) {
        ESP_LOGW(TAG, "Tool %s timed out", name.c_str());
        return false;
    }

    cJSON* root = cJSON_Parse(payload.c_str());
    if (root == nullptr) {
        return false;
    }

    bool ok = false;
    cJSON* error = cJSON_GetObjectItem(root, "error");
    if (cJSON_IsObject(error)) {
        cJSON* error_message = cJSON_GetObjectItem(error, "message");
        text = cJSON_IsString(error_message) ? error_message->valuestring : "error";
    } else {
        cJSON* result = cJSON_GetObjectItem(root, "result");
        cJSON* content = cJSON_IsObject(result) ? cJSON_GetObjectItem(result, "content") : nullptr;
        cJSON* first = cJSON_IsArray(content) ? cJSON_GetArrayItem(content, 0) : nullptr;
        cJSON* value = cJSON_IsObject(first) ? cJSON_GetObjectItem(first, "text") : nullptr;
        if (cJSON_IsString(value)) {
            text = value->valuestring;
            ok = true;
        }
    }

    cJSON_Delete(root);
    return ok;
}

void TelegramBot::PollOnce() {
    std::string query = "timeout=" + std::to_string(kPollTimeoutSeconds) +
                        "&allowed_updates=%5B%22message%22%5D";
    if (offset_ > 0) {
        query += "&offset=" + std::to_string(offset_);
    }

    std::string response;
    if (!CallApi("getUpdates", query, "", kPollHttpTimeoutMs, response)) {
        return;
    }

    cJSON* root = cJSON_Parse(response.c_str());
    if (root == nullptr) {
        return;
    }
    cJSON* ok = cJSON_GetObjectItem(root, "ok");
    cJSON* result = cJSON_GetObjectItem(root, "result");
    if (!cJSON_IsTrue(ok) || !cJSON_IsArray(result)) {
        cJSON_Delete(root);
        return;
    }

    cJSON* update = nullptr;
    cJSON_ArrayForEach(update, result) {
        cJSON* update_id = cJSON_GetObjectItem(update, "update_id");
        if (cJSON_IsNumber(update_id)) {
            offset_ = static_cast<int64_t>(update_id->valuedouble) + 1;
        }

        cJSON* message = cJSON_GetObjectItem(update, "message");
        if (!cJSON_IsObject(message)) {
            continue;
        }
        cJSON* text = cJSON_GetObjectItem(message, "text");
        if (!cJSON_IsString(text) || text->valuestring == nullptr) {
            continue;
        }
        cJSON* chat = cJSON_GetObjectItem(message, "chat");
        cJSON* chat_id = cJSON_IsObject(chat) ? cJSON_GetObjectItem(chat, "id") : nullptr;
        if (!cJSON_IsNumber(chat_id)) {
            continue;
        }
        char from_chat[32];
        snprintf(from_chat, sizeof(from_chat), "%lld",
                 static_cast<long long>(chat_id->valuedouble));

        HandleCommand(text->valuestring, from_chat);
    }

    cJSON_Delete(root);
}

void TelegramBot::HandleCommand(const std::string& raw_text, const std::string& from_chat_id) {
    if (chat_id_.empty()) {
        std::string body = "{\"chat_id\":\"" + from_chat_id +
                           "\",\"text\":\"Tu chat_id es " + from_chat_id + ".\"}";
        std::string response;
        CallApi("sendMessage", "", body, kApiHttpTimeoutMs, response);
        ESP_LOGI(TAG, "Reported chat_id %s", from_chat_id.c_str());
        return;
    }
    if (from_chat_id != chat_id_) {
        ESP_LOGW(TAG, "Ignoring message from unauthorized chat %s", from_chat_id.c_str());
        return;
    }

    std::string text = Trim(raw_text);
    if (text.empty() || text[0] != '/') {
        return;
    }

    size_t space = text.find(' ');
    std::string command = space == std::string::npos ? text : text.substr(0, space);
    std::string rest = space == std::string::npos ? "" : Trim(text.substr(space + 1));

    // Telegram appends the bot name to commands in groups: /ayuda@MyBot
    size_t at = command.find('@');
    if (at != std::string::npos) {
        command = command.substr(0, at);
    }
    command = CanonicalCommand(command);

    if (command == "/ayuda") {
        SendMessage(BuildHelpText());
        return;
    }

    if (command == "/recordar") {
        size_t split = rest.find(' ');
        std::string when_spec = split == std::string::npos ? rest : rest.substr(0, split);
        std::string reminder_text = split == std::string::npos ? "" : Trim(rest.substr(split + 1));
        int64_t now = static_cast<int64_t>(time(nullptr));
        int64_t due = 0;
        if (when_spec.empty() || reminder_text.empty() || !ParseWhen(when_spec, now, due)) {
            SendMessage("Uso: /recordar 10m Sacar la ropa (también 2h o 18:30)");
            return;
        }
        auto reminders = LoadReminders();
        if (reminders.size() >= kMaxReminders) {
            SendMessage("Ya hay " + std::to_string(kMaxReminders) +
                        " recordatorios. Cancelá alguno antes de agregar otro.");
            return;
        }
        if (reminder_text.size() > kMaxReminderText) {
            reminder_text.resize(kMaxReminderText);
        }
        reminder_text = Sanitize(reminder_text);
        reminders.push_back({due, reminder_text});
        std::sort(reminders.begin(), reminders.end(),
                  [](const Reminder& a, const Reminder& b) { return a.due < b.due; });
        SaveReminders(reminders);
        SendMessage("Recordatorio anotado: " + reminder_text + " — " + FormatTime(due));
        return;
    }

    if (command == "/recordatorios") {
        auto reminders = LoadReminders();
        if (reminders.empty()) {
            SendMessage("No hay recordatorios pendientes.");
            return;
        }
        std::string reply =
            "Recordatorios pendientes (" + std::to_string(reminders.size()) + "):";
        for (size_t i = 0; i < reminders.size(); ++i) {
            reply += "\n" + std::to_string(i + 1) + ". " + FormatTime(reminders[i].due) + " — " +
                     reminders[i].text;
        }
        SendMessage(reply);
        return;
    }

    if (command == "/cancelar") {
        auto reminders = LoadReminders();
        int index = rest.empty() ? 0 : std::atoi(rest.c_str());
        if (index < 1 || index > static_cast<int>(reminders.size())) {
            SendMessage("No existe el recordatorio " + rest + ".");
            return;
        }
        std::string removed = reminders[index - 1].text;
        reminders.erase(reminders.begin() + (index - 1));
        SaveReminders(reminders);
        SendMessage("Recordatorio " + std::to_string(index) + " cancelado: " + removed);
        return;
    }

    if (command == "/aviso") {
        if (rest.empty()) {
            SendMessage("Uso: /aviso Hola");
            return;
        }
        std::string message = rest;
        if (message.size() > kMaxReminderText) {
            message.resize(kMaxReminderText);
        }
        message = Sanitize(message);
        Application::GetInstance().Schedule([message]() {
            Board::GetInstance().GetDisplay()->ShowNotification(message);
        });
        SendMessage("Mostrado en pantalla: " + message);
        return;
    }

    if (command == "/estado") {
        auto reminders = LoadReminders();
        std::string reply = "Hora: " + FormatClock() + "\nEstado: " +
                            StateName(Application::GetInstance().GetDeviceState()) +
                            "\nRecordatorios pendientes: " + std::to_string(reminders.size());
        SendMessage(reply);
        return;
    }

    if (command == "/dispositivo") {
        std::string out;
        if (InvokeTool("self.get_device_status", "", out)) {
            SendMessage(out);
        } else {
            SendMessage("No pude leer el dispositivo: " + (out.empty() ? "sin respuesta" : out));
        }
        return;
    }

    if (command == "/volumen" || command == "/brillo") {
        bool is_volume = command == "/volumen";
        char* end = nullptr;
        long value = rest.empty() ? -1 : std::strtol(rest.c_str(), &end, 10);
        long minimum = is_volume ? 0 : 1;
        if (rest.empty() || end == nullptr || *end != '\0' || value < minimum || value > 100) {
            SendMessage("Uso: " + command + (is_volume ? " 60 (0-100)" : " 60 (1-100)"));
            return;
        }
        std::string args = std::string("{\"") + (is_volume ? "volume" : "brightness") + "\":" +
                           std::to_string(value) + "}";
        std::string tool =
            is_volume ? "self.audio_speaker.set_volume" : "self.screen.set_brightness";
        std::string out;
        if (!InvokeTool(tool, args, out)) {
            SendMessage("No pude ejecutar " + tool + ": " + (out.empty() ? "sin respuesta" : out));
            return;
        }
        SendMessage(std::string(is_volume ? "Volumen" : "Brillo") + " del dispositivo en " +
                    std::to_string(value) + ".");
        return;
    }

    if (command == "/tema") {
        if (rest != "light" && rest != "dark") {
            SendMessage("Uso: /tema light|dark");
            return;
        }
        std::string out;
        if (!InvokeTool("self.screen.set_theme", "{\"theme\":\"" + rest + "\"}", out)) {
            SendMessage("No pude cambiar el tema: " + (out.empty() ? "sin respuesta" : out));
            return;
        }
        SendMessage("Tema: " + rest + ".");
        return;
    }

    if (command == "/bw") {
        if (rest.empty()) {
            SendMessage("Uso: /bw clima de argentina");
            return;
        }
        SendMessage("Buscando: " + rest);
        std::string args = "{\"query\":\"" + JsonEscape(rest) + "\"}";
        std::string out;
        if (!InvokeTool("web.search", args, out, kSearchWaitMs)) {
            SendMessage("No pude buscar: " + (out.empty() ? "sin respuesta" : out));
            return;
        }
        SendMessage(out);
        return;
    }

    if (command == "/tool") {
        size_t split = rest.find(' ');
        std::string tool = split == std::string::npos ? rest : rest.substr(0, split);
        std::string args = split == std::string::npos ? "" : Trim(rest.substr(split + 1));
        if (tool.empty()) {
            std::vector<std::string> names;
            if (!ListTools(names)) {
                SendMessage("No pude leer la lista de herramientas del firmware.");
                return;
            }
            std::string reply = "Herramientas del firmware (" + std::to_string(names.size()) + "):";
            for (const auto& name : names) {
                reply += "\n" + name;
            }
            reply += "\n\nBuscador web: /bw clima de argentina";
            reply += "\nAvanzado: /tool <nombre> <json>";
            SendMessage(reply);
            return;
        }
        std::string out;
        if (!InvokeTool(tool, args, out)) {
            SendMessage("No pude ejecutar " + tool + ": " + (out.empty() ? "sin respuesta" : out));
            return;
        }
        SendMessage(tool + ": " + out);
        return;
    }

    SendMessage("No conozco ese comando.\n" + BuildHelpText());
}

std::vector<TelegramBot::Reminder> TelegramBot::LoadReminders() {
    std::vector<Reminder> reminders;
    Settings settings(kReminderNamespace, false);
    std::string raw = settings.GetString(kReminderKey, "");

    size_t start = 0;
    while (start < raw.size()) {
        size_t end = raw.find('\n', start);
        if (end == std::string::npos) {
            end = raw.size();
        }
        std::string line = raw.substr(start, end - start);
        start = end + 1;
        size_t sep = line.find('|');
        if (sep == std::string::npos) {
            continue;
        }
        int64_t due = std::atoll(line.substr(0, sep).c_str());
        std::string text = line.substr(sep + 1);
        if (due > 0 && !text.empty()) {
            reminders.push_back({due, text});
        }
    }

    std::sort(reminders.begin(), reminders.end(),
              [](const Reminder& a, const Reminder& b) { return a.due < b.due; });
    return reminders;
}

void TelegramBot::SaveReminders(const std::vector<Reminder>& reminders) {
    std::string raw;
    for (const auto& reminder : reminders) {
        raw += std::to_string(reminder.due) + "|" + reminder.text + "\n";
    }
    Settings settings(kReminderNamespace, true);
    if (raw.empty()) {
        settings.EraseKey(kReminderKey);
    } else {
        settings.SetString(kReminderKey, raw);
    }
}

void TelegramBot::Notify(const std::string& text) {
    SendMessage(text);
    Application::GetInstance().Schedule([text]() {
        Board::GetInstance().GetDisplay()->ShowNotification(text);
    });
}

void TelegramBot::CheckReminders() {
    int64_t now = static_cast<int64_t>(time(nullptr));
    if (now < kMinValidTime) {
        return;
    }

    auto reminders = LoadReminders();
    std::vector<Reminder> pending;
    bool fired = false;
    for (const auto& reminder : reminders) {
        if (reminder.due <= now) {
            ESP_LOGI(TAG, "Reminder due: %s", reminder.text.c_str());
            Notify("Recordatorio: " + reminder.text);
            fired = true;
        } else {
            pending.push_back(reminder);
        }
    }
    if (fired) {
        SaveReminders(pending);
    }
}
