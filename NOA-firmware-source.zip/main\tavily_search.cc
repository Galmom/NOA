#include "tavily_search.h"

#include <esp_crt_bundle.h>
#include <esp_http_client.h>
#include <esp_log.h>

#include <atomic>
#include <string>

#include "application.h"
#include "mcp_server.h"

#if __has_include("tavily_config.h")
#include "tavily_config.h"
#endif

#ifndef TAVILY_API_KEY
#define TAVILY_API_KEY ""
#endif

#define TAG "Tavily"

namespace {

constexpr const char* kTavilyUrl = "https://api.tavily.com/search";
constexpr int kHttpTimeoutMs = 20000;

// The request blocks the calling thread, so a second concurrent call is
// refused instead of queued.
std::atomic<bool> g_search_in_progress{false};

std::string Truncate(const std::string& text, size_t limit) {
    if (text.size() <= limit) {
        return text;
    }
    return text.substr(0, limit) + "...";
}

bool HttpPostJson(const std::string& body, const std::string& api_key, std::string& response,
                  int& status) {
    response.clear();
    status = 0;

    esp_http_client_config_t config = {};
    config.url = kTavilyUrl;
    config.method = HTTP_METHOD_POST;
    config.crt_bundle_attach = esp_crt_bundle_attach;
    config.timeout_ms = kHttpTimeoutMs;
    config.buffer_size = 2048;
    config.buffer_size_tx = 2048;

    esp_http_client_handle_t client = esp_http_client_init(&config);
    if (client == nullptr) {
        ESP_LOGW(TAG, "HTTP client init failed");
        return false;
    }

    std::string auth = "Bearer " + api_key;
    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_header(client, "Authorization", auth.c_str());

    bool ok = false;
    if (esp_http_client_open(client, body.size()) == ESP_OK) {
        int written = esp_http_client_write(client, body.data(), body.size());
        if (written != static_cast<int>(body.size())) {
            ESP_LOGW(TAG, "Short write: %d/%u", written, static_cast<unsigned>(body.size()));
        }
        esp_http_client_fetch_headers(client);
        status = esp_http_client_get_status_code(client);

        char buffer[1024];
        int read = 0;
        while ((read = esp_http_client_read(client, buffer, sizeof(buffer))) > 0) {
            response.append(buffer, read);
        }
        ok = status == 200;
        if (!ok) {
            ESP_LOGW(TAG, "search returned HTTP %d", status);
        }
    } else {
        ESP_LOGW(TAG, "HTTP open failed");
    }

    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    return ok;
}

std::string FormatResults(const std::string& json) {
    cJSON* root = cJSON_Parse(json.c_str());
    if (root == nullptr) {
        return "";
    }

    std::string out;
    cJSON* answer = cJSON_GetObjectItem(root, "answer");
    if (cJSON_IsString(answer) && answer->valuestring[0] != '\0') {
        out += "Answer: " + Truncate(answer->valuestring, 600);
    }

    cJSON* results = cJSON_GetObjectItem(root, "results");
    if (cJSON_IsArray(results)) {
        int count = 0;
        cJSON* item = nullptr;
        cJSON_ArrayForEach(item, results) {
            if (count >= 3) {
                break;
            }
            cJSON* title = cJSON_GetObjectItem(item, "title");
            cJSON* url = cJSON_GetObjectItem(item, "url");
            cJSON* content = cJSON_GetObjectItem(item, "content");
            std::string line = "\n- ";
            line += cJSON_IsString(title) ? title->valuestring : "(no title)";
            line += " (";
            line += cJSON_IsString(url) ? url->valuestring : "";
            line += "): ";
            line += cJSON_IsString(content) ? Truncate(content->valuestring, 220) : "";
            out += line;
            ++count;
        }
    }

    cJSON_Delete(root);
    return out;
}

}  // namespace

void RegisterTavilySearchTool(McpServer& server) {
    server.AddTool("web.search",
                   "Search the web for recent information using Tavily. Use this when answering "
                   "questions that require current or sourced information.",
                   PropertyList({Property("query", kPropertyTypeString),
                                 Property("max_results", kPropertyTypeInteger, 3, 1, 10)}),
                   [](const PropertyList& properties) -> ToolResult {
                       if (TAVILY_API_KEY[0] == '\0') {
                           return std::unexpected(
                               "Tavily API key is not configured. Set it in tavily_config.h and "
                               "rebuild.");
                       }

                       auto query = properties["query"].value<std::string>();
                       int max_results = properties["max_results"].value<int>();
                       if (max_results < 1) {
                           max_results = 1;
                       } else if (max_results > 10) {
                           max_results = 10;
                       }

                       // The request takes seconds; lower the priority while it blocks the
                       // thread, the same way the camera capture tool does.
                       TaskPriorityReset priority_reset(1);

                       bool expected = false;
                       if (!g_search_in_progress.compare_exchange_strong(expected, true)) {
                           return std::unexpected("A Tavily search is already in progress");
                       }

                       cJSON* payload = cJSON_CreateObject();
                       cJSON_AddStringToObject(payload, "query", query.c_str());
                       cJSON_AddNumberToObject(payload, "max_results", max_results);
                       cJSON_AddBoolToObject(payload, "include_answer", true);
                       char* body = cJSON_PrintUnformatted(payload);
                       cJSON_Delete(payload);

                       std::string response;
                       int status = 0;
                       bool ok = body != nullptr &&
                                 HttpPostJson(body, TAVILY_API_KEY, response, status);
                       if (body != nullptr) {
                           cJSON_free(body);
                       }
                       g_search_in_progress.store(false);

                       if (!ok) {
                           std::string detail = Truncate(response, 200);
                           return std::unexpected("Tavily request failed: HTTP " +
                                                  std::to_string(status) + " " + detail);
                       }

                       std::string formatted = FormatResults(response);
                       if (formatted.empty()) {
                           return std::unexpected("No results from Tavily");
                       }
                       return Truncate(formatted, 1800);
                   });
}
