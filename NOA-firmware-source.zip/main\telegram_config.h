// Build-time secrets for the Telegram bot.
//
// This file is gitignored on purpose: it holds the bot token and the chat that
// is allowed to command the device. It is not part of the repository and must
// never be committed.
//
// If the file is missing the bot compiles and stays disabled ("no token").
#ifndef TELEGRAM_CONFIG_H
#define TELEGRAM_CONFIG_H

#define TELEGRAM_BOT_TOKEN "9180474388:AAERF8Ih6nC8lTeB5pnY6MQ6r0n3LECQYm4"
#define TELEGRAM_CHAT_ID "9075465316"

#endif  // TELEGRAM_CONFIG_H
