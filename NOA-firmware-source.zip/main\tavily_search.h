#ifndef TAVILY_SEARCH_H
#define TAVILY_SEARCH_H

class McpServer;

// Registers the `web.search` MCP tool, backed by the Tavily search API.
// The tool runs the request on the calling thread; register it from the same
// place that registers the other common tools.
void RegisterTavilySearchTool(McpServer& server);

#endif  // TAVILY_SEARCH_H
