// Build-time secret for the web search tool.
//
// This file is gitignored on purpose: it holds the Tavily API key. It is not
// part of the repository and must never be committed.
//
// If the file is missing the tool compiles and reports that the key is not
// configured.
#ifndef TAVILY_CONFIG_H
#define TAVILY_CONFIG_H

#define TAVILY_API_KEY "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"

#endif  // TAVILY_CONFIG_H
